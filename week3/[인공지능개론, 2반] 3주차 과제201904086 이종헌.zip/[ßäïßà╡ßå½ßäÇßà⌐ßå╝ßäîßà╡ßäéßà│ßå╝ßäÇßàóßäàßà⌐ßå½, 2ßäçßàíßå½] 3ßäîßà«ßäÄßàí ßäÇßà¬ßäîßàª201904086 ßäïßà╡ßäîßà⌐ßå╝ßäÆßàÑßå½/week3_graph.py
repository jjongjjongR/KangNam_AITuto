#conda env list
#conda actate ai

# x=10
# y=5
# z = x + y
# print(z)

import matplotlib.pyplot as plt
x = [1, 2,3, 4]
y = [10, 20, 25, 30]

plt.plot(x,y)
plt.title("Sample Plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.show()

