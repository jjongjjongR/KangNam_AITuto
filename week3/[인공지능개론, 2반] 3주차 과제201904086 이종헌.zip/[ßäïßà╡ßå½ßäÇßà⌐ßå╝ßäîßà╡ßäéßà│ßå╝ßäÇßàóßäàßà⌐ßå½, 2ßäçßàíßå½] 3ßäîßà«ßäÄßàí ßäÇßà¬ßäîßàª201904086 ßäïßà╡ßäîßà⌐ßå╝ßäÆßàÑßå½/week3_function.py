def greet(name):
    return "안녕하세요." + name + "!"
print (greet("Bob"))