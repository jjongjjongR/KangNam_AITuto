age = 25
height = 1.75
name = "Alice"

print("이름"+name+"\n나이"+str(age)+"\n키"+ str(height))