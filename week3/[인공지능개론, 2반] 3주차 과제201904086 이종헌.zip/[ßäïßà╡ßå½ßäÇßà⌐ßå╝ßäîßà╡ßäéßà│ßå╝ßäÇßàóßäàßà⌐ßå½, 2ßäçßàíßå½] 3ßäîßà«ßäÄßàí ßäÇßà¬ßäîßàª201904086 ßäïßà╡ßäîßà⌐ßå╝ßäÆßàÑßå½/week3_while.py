count = 0
while count < 5: #while 반복문
    print(count)
    count += 1