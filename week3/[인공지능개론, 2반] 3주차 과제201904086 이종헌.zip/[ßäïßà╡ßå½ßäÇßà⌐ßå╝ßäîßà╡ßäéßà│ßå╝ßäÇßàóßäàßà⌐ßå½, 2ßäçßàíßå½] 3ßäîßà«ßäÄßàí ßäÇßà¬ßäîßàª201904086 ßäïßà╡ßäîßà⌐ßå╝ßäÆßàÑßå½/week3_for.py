for i in range(5): #for 반복문
    print(i)