score = 85
if score >= 90: #if 조건문
    print("A")
elif score >= 80:
    print("B")
else:
    print("C")